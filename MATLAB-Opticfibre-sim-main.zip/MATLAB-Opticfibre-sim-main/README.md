# MATLAB-Opticfibre-sim
Data-Loss in Optic Fibers while connected to a data splicer ( Simulation ) 
.
.
.
.
.
Change the Variables as you want
